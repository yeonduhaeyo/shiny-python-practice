from pathlib import Path

app_dir = Path(__file__).resolve().parent

data_dir = app_dir / "data"