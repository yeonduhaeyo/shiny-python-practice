from pathlib import Path
import geopandas as gpd

app_dir = Path(__file__).resolve().parent

data_dir = app_dir / "data"
geo_dir = data_dir / "geo"

SIGUNGU_GEOJSON = geo_dir / "sigungu.geojson"
gdf_sigungu = gpd.read_file(SIGUNGU_GEOJSON)