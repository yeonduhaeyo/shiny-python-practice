from shiny import ui, module

@module.ui
def page_appendix_ui():
    return ui.nav_panel(
        "부록",
        ui.h3("부록"),
        ui.p("데이터 요약과 성능 리포트를 정리합니다(이후 레슨에서 구현)."),
    )

@module.server
def page_appendix_server(input, output, session):
    # 이후 레슨에서 데이터 요약/성능 리포트 출력 구현
    pass