from pathlib import Path

app_dir = Path(__file__).resolve().parent

data_dir = app_dir / "data"
model_dir = app_dir / "models"

# 필요 시: 기본 파일 경로(이후 레슨에서 사용)
train_path = data_dir / "train.csv"
model_path = model_dir / "model.joblib"
metrics_path = model_dir / "metrics.json"