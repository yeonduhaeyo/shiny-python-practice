from shiny import ui, module

@module.ui
def page_data_ui():
    return ui.nav_panel(
        "데이터 요약",
        ui.h3("데이터 요약"),
        ui.card(
            ui.card_header("데이터 요약"),
            ui.p("head / info / describe / 메타 요약 출력 위치"),
        ),
    )

@module.server
def page_data_server(input, output, session):
    pass