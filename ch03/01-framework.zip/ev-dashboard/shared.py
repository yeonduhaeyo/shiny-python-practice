from pathlib import Path

app_dir = Path(__file__).resolve().parent

# 다음 레슨에서 df 로드/전처리를 고정합니다.
# 예: df = pd.read_csv(app_dir / "data" / "ev_data.csv")